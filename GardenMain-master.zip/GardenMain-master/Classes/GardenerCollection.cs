﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garden.Classes
{
    class GardenerCollection
    {
        public List<IGardener> Gardeners { get; private set; } = new List<IGardener>();
    }
}
