﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Media;

namespace GardenAndGardeners.Classes
{
    /*
    class GridInitioanalizator
    {
        private const int cntColumns = 30;
        private const int cntRows = 30;
        private Grid grid { get; }


        public GridInitioanalizator(Grid grid)
        {
            this.grid = grid;
        }

        private void AddColums()
        {
            for (int i = 0; i < cntColumns; i++)
            {
                ColumnDefinition cd = new ColumnDefinition();
                grid.ColumnDefinitions.Add(cd);
            }
        }

        private void AddRows()
        {
            for (int i = 0; i < cntRows; i++)
            {
                RowDefinition rd = new RowDefinition();
                grid.RowDefinitions.Add(rd);
            }
        }

        private void SetRowsStyle()
        {
            for (int i = 0; i < cntColumns; i++)
            {
                for (int j = 0; j < cntRows; j++)
                {
                    this.SetCellStyle(j, i);
                }
            }
        }

        private void SetCellStyle(int rowNum, int colNum)
        {
            System.Windows.Controls.Border border = new System.Windows.Controls.Border()
            {
                Background = Brushes.Yellow,
                BorderThickness = new System.Windows.Thickness(1, 1, 1, 1),
                BorderBrush = Brushes.Green

            };
            border.SetValue(Grid.ColumnProperty, colNum);
            border.SetValue(Grid.RowProperty, rowNum);
            grid.Children.Add(border);
        }

        public void Initialize()
        {
            this.AddColums();
            this.AddRows();
            this.SetRowsStyle();
        }
    }
    */
}
