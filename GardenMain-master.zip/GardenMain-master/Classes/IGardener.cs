﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Garden.Classes
{
    abstract class IGardener
    {
        public int GardenerNumber {get; private set;}
        public IGardener(int gardenerNumber)
        {
            this.GardenerNumber = gardenerNumber;
        }

        public void TakeGardenCell(IGarden garden, int rowNum, int colNum)
        {
            garden[rowNum, colNum] = this.GardenerNumber;
        }
    }
}
